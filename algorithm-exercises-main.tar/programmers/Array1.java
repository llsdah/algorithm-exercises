package studyProgrammers;

public class Array1 {

}
