package studyProgrammers;

public class 사칙연산 {

	public static void main(String[] args) {
		
		
		
	}

}

