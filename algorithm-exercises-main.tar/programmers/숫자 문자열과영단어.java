
import java.util.*;

class Solution {
    public int solution(String s) {
        int answer = 0;
        String str = "";
        s = s.replace("zero","0");
        s = s.replace("one","1");
        s = s.replace("two","2");
        s = s.replace("three","3");
        s = s.replace("four","4");
        s = s.replace("five","5");
        s = s.replace("six","6");
        s = s.replace("seven","7");
        s = s.replace("eight","8");
        s = s.replace("nine","9");

        /*
        char[] ch = s.toCharArray();
        for(int i =0; i < ch.length;i++){
            if(ch[i]-'0'>=0&&ch[i]-'0'<=9){
                str+= ch[i];
            }else{
                move(i,ch);
            }
        }
        */

        answer= Integer.valueOf(s);
        return answer;
    }

}
