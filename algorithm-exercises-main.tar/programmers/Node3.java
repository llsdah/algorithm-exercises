package studyProgrammers;

/*
방의 갯수 

이미지를 보면서 해야됩니다. 

*/
public class Node3 {

}
